
const SF = {
  get(key, fallback){ try{return JSON.parse(localStorage.getItem('sf_'+key)) ?? fallback}catch{return fallback} },
  set(key, value){ localStorage.setItem('sf_'+key, JSON.stringify(value)); },
  user(){ return this.get('session', null); },
  accounts(){ return this.get('accounts', []); },
  missions(){ return this.get('missions', []); },
  currentMission(){ return this.get('currentMission', null); },
  requireUser(){ if(!this.user()){ location.href='STARFORGE_Sign_In.html'; return false; } return true; },
  signOut(){ localStorage.removeItem('sf_session'); location.href='index.html'; },
  esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
};
