STARFORGE — FRONTEND INTEGRATED DEMO

Start:
1. Open this folder in VS Code.
2. Install/use the Live Server extension.
3. Open index.html and choose Open with Live Server.

Integrated frontend flow:
Homepage -> Crew Registration -> Sign In -> Dashboard -> Mission Configuration -> 2D Design Studio -> Dashboard.

Demo functionality:
- Registration creates a demo profile in this browser.
- Sign-in checks the demo profile stored in this browser.
- Dashboard stores and lists missions.
- Mission Configuration saves mission details and opens the selected mission's design studio.
- Design Studio restores and saves 2D placements per mission.
- Data is stored in browser localStorage, not a server or cloud database.

Important:
This is a frontend demonstration only. It is not secure authentication. Demo passwords are stored locally in the browser and must never be real passwords. Data stays in the same browser profile and can be lost if browser storage is cleared. No backend, database, engineering validation, or cloud sync is included.
